#This is a landingPage I created as a refrence to my web dev work and skills.

Contact:>

Email: abanoub.samuel@hotmail.com

LinkedIn: https://www.linkedin.com/in/abanoubsml/

Hope you like the website.